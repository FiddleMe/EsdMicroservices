export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyDODLVMuwrvGobMXkI89DktOLgwf0mCM24",
    authDomain: "joaq-lab.firebaseapp.com",
    databaseURL: "https://joaq-lab.firebaseio.com",
    projectId: "joaq-lab",
    storageBucket: "joaq-lab.appspot.com",
    messagingSenderId: "794748950011",
    appId: "1:794748950011:web:815fe385e7317c11"
  },
  userApi: 'https://us-central1-joaq-lab.cloudfunctions.net/api'
};
