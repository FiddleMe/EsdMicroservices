# How to build a role-based REST API with Firebase

This sample is published as part of the corresponding [blog article](https://www.toptal.com/firebase/role-based-firebase-authentication)
